﻿{
	"version": 1706614278,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/metal-sheet0.png",
		"images/sprite-sheet0.png",
		"images/botao_ligado_desligado-sheet0.png",
		"images/botao_ligado_desligado-sheet1.png",
		"images/lentes-sheet0.png",
		"images/laser-sheet0.png",
		"images/fundo-sheet0.png",
		"images/sprite2-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}